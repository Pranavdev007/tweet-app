package com.tweetapp.repository;

import com.tweetapp.domain.UserModel;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

/**
 * @author Satish Patri
 * @project tweetapp-backend
 */
@DataMongoTest
@RunWith(SpringRunner.class)
public class UserRepositoryTests {

    @Autowired
    private UserRepository userRepository;


    @Test
    public void testSaveUser() {
        final UserModel userModel = UserModel.builder()
                .username("satish_10")
                .firstName("Satish")
                .lastName("Patri")
                .email("sp07soa@gmail.com")
                .contactNum("7978797877")
                .password("password")
                .build();
        userRepository.save(userModel);
        Assertions.assertThat(userModel.getUsername()).isEqualTo("satish_10");
    }

    @Test
    public void testFindUserByName() {
        final String username = "satish_10";
        final UserModel user = UserModel.builder()
                .username("satish_10")
                .firstName("Satish")
                .lastName("Patri")
                .email("sp07soa@gmail.com")
                .build();
        userRepository.findByUsername(username);
        Assertions.assertThat(username).isEqualTo(user.getUsername());
    }

    @Test
    public void testSearchByUserName() {
        final String userName = "satish_10";

        final List<UserModel> userModelList = Arrays.asList(
                UserModel.builder()
                        .username("satish_10")
                        .firstName("Satish")
                        .lastName("Patri")
                        .email("sp07soa@gmail.com")
                        .build(),
                UserModel.builder()
                        .username("satish_10")
                        .firstName("Siddharth")
                        .lastName("Salar")
                        .email("siddharthsalar@gmail.com")
                        .build()
        );

        userRepository.searchByUsername(userName);
        Assertions.assertThat(userModelList.size()).isGreaterThanOrEqualTo(2);
    }
}
