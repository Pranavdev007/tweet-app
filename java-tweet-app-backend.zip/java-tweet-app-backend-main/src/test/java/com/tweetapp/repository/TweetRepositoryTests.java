package com.tweetapp.repository;

import com.tweetapp.domain.UserModel;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Satish Patri
 * @project tweetapp-backend
 */
@DataMongoTest
@RunWith(SpringRunner.class)
public class TweetRepositoryTests {

    @Autowired
    private TweetRepository userRepository;

    @Test
    public void testFindUserByName() {
        final String username = "satish_10";
        final UserModel user = UserModel.builder()
                .username("satish_10")
                .firstName("Satish")
                .lastName("Patri")
                .email("sp07soa@gmail.com")
                .build();
        userRepository.findByUsername(username);
        Assertions.assertThat(username).isEqualTo(user.getUsername());
    }

}
