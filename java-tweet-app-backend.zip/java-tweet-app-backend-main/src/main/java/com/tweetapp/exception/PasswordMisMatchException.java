package com.tweetapp.exception;

public class PasswordMisMatchException extends Exception {

    public PasswordMisMatchException(String msg) {
        super(msg);
    }

}
