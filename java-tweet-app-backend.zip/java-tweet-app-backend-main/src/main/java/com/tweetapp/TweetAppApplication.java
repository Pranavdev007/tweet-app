package com.tweetapp;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.TimeZone;

@SpringBootApplication
@Log4j2
public class TweetAppApplication {

    public static void main(String[] args) {
        log.info("Initialization");
        TimeZone.setDefault(TimeZone.getDefault());
        SpringApplication.run(TweetAppApplication.class, args);
    }

}
