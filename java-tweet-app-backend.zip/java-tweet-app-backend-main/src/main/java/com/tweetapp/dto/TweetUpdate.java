package com.tweetapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * @author Satish Patri
 * @project tweetapp-backend
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TweetUpdate {
    private String tweetId;
    private String tweetText;
    private String tweetDate = Instant.now().toString();
}
