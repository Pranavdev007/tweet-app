package com.tweetapp.repository;

import com.tweetapp.domain.Tweet;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Satish Patri
 * @project tweetapp-backend
 */
@Repository("tweet-repository")
public interface TweetRepository extends MongoRepository<Tweet, String> {

    List<Tweet> findByUsername(String username);
}
