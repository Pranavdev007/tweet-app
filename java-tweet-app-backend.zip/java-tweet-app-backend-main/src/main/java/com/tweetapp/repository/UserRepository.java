package com.tweetapp.repository;

import com.tweetapp.domain.UserModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Satish Patri
 * @project tweetapp-backend
 */
@Repository("user-repository")
public interface UserRepository extends MongoRepository<UserModel, String> {

    UserModel findByUsername(String username);

    @Query("{'username':{'$regex':'?0','$options':'i'}}")
    List<UserModel> searchByUsername(String username);
}
